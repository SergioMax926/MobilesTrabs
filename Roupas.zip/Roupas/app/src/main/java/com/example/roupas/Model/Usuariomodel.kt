package com.example.roupas.Model

class Usuariomodel {

    var email: String?
    var senha: String?
    var cpf: String?
    var name: String?
    var phone: String?

    constructor(){
        this.email = null
        this.senha = null
        this.cpf = null
        this.name = null
        this.phone = null
    }

    constructor(email: String?, senha: String?, cpf:String?, name:String?, phone:String?) {
        this.email = email
        this.senha = senha
        this.cpf = cpf
        this.phone = phone
        this.name = name
    }

}