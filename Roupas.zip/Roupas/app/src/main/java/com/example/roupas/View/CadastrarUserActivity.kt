package com.example.roupas.View

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.roupas.Model.Usuariomodel
import com.example.roupas.Presenter.ConfigBD
import com.example.roupas.databinding.ActivityCadastrarUserBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class CadastrarUserActivity : AppCompatActivity() {
    lateinit var bind : ActivityCadastrarUserBinding
    var bd = ConfigBD.getConexaoUsuario()
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityCadastrarUserBinding.inflate(layoutInflater)
        setContentView(bind.root)


        bind.btcadastrar.setOnClickListener {
            var user = Usuariomodel()
            user.email = bind.edtlogin.text.toString()
            user.senha = bind.edtsenha.text.toString()
            bd.createUserWithEmailAndPassword(user.email.toString(),user.senha.toString()).addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "Usuario Cadastrado com sucesso")
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "createUserWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "Usuario não cadastrado.",
                        Toast.LENGTH_SHORT).show()
                }
            }
            db.collection("users").document("user.cpf.toString()").add("user")

        } //fim cadastrar


    }//fim oncreate

}