package com.example.roupas.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.roupas.databinding.ActivityCadastroFornecedorBinding

class CadastroFornecedorActivity : AppCompatActivity() {
    lateinit var bind : ActivityCadastroFornecedorBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        bind = ActivityCadastroFornecedorBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(bind.root)
    }
}