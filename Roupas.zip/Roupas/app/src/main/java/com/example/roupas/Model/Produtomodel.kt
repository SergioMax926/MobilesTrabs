package com.example.roupas.Model

class Produtomodel {
    var code: String?
    var name: String?
    var description: String?
    var quantidade: Int?

    constructor(){
        this.code = null
        this.description = null
        this.name = null
        this.quantidade = null
    }

    constructor(code:String?, name:String?, description:String?, quantidade:Int?){
        this.code = code
        this.name = name
        this.description = description
        this.quantidade = quantidade
    }

}