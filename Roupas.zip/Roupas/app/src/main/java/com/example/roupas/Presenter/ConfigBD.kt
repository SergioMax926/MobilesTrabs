package com.example.roupas.Presenter

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class ConfigBD {

    companion object Conexao{
        var auth = Firebase.auth

        fun getConexaoUsuario(): FirebaseAuth {
            if( auth == null){
                auth = Firebase.auth
                return auth
            }else{
                return auth
            }

        }//fim getconexao



    }//fim object
}