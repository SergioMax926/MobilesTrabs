package com.example.roupas.Model

class Fornecedormodel {
    var cnpj: String?
    var nome: String?
    var produto: String?

    constructor(){
        this.cnpj = null
        this.nome = null
        this.produto = null
    }

}